/**
 * clients/9router.js — real LLM client for createReasoner()
 * -----------------------------------------------
 * Implements the `client.chat({ systemPrompt, messages, tools })` contract
 * that src/reasoner.js expects, talking to an OpenAI-compatible
 * `/chat/completions` endpoint with native tool/function calling.
 *
 * ASSUMPTION (no vendor docs were provided for "9router" — flag/confirm if
 * wrong): it is an OpenAI-compatible chat-completions gateway/router — the
 * same shape used by OpenRouter, most local model servers (Ollama, LM
 * Studio, vLLM), and most "LLM router" products. If the real 9router API
 * differs (different auth header, different tool_call schema, different
 * base path), only this file needs to change — reasoner.js and the rest of
 * the loop are unaffected.
 *
 * Config via env (see .env.example):
 *   NINEROUTER_BASE_URL       e.g. https://api.9router.example/v1
 *   NINEROUTER_API_KEY        bearer token
 *   NINEROUTER_MODEL          model id, e.g. "gpt-4o-mini"
 *   NINEROUTER_RESPONSE_FORMAT  optional: "json_object" (forces
 *     response_format:{type:"json_object"} on every request). Only turn
 *     this on if your gateway supports OpenAI's structured-output param —
 *     it is off by default because we have no docs confirming it.
 *
 * `stream` is always explicitly forced to `false`. The original bug report
 * ("Unexpected non-whitespace character after JSON at position N") is the
 * classic symptom of a provider streaming NDJSON/SSE chunks back even
 * though nothing asked for streaming — res.json() then chokes on the 2nd+
 * JSON object concatenated after the 1st. Fixed by (a) never omitting
 * stream:false and (b) falling back to a balanced-brace scan that pulls out
 * just the first complete JSON object if the body still isn't clean.
 *
 * Pure JavaScript (ES modules), uses global fetch (Node >= 18).
 */

import { createLogger } from '../logger.js';

const log = createLogger('clients:9router');

const DEFAULT_TIMEOUT_MS = 60_000;

/**
 * @param {Object} [opts]
 * @param {string} [opts.baseUrl] default: process.env.NINEROUTER_BASE_URL
 * @param {string} [opts.apiKey] default: process.env.NINEROUTER_API_KEY
 * @param {string} [opts.model] default: process.env.NINEROUTER_MODEL
 * @param {number} [opts.timeoutMs]
 * @param {number} [opts.temperature]
 * @returns {{chat: Function}} a ReasonerClient for createReasoner({ client })
 */
export function createNineRouterClient(opts = {}) {
  const {
    baseUrl = process.env.NINEROUTER_BASE_URL,
    apiKey = process.env.NINEROUTER_API_KEY,
    model = process.env.NINEROUTER_MODEL,
    timeoutMs = DEFAULT_TIMEOUT_MS,
    temperature = 0.2,
    responseFormat = process.env.NINEROUTER_RESPONSE_FORMAT || null,
  } = opts;

  if (!baseUrl) throw configError('NINEROUTER_BASE_URL is required (env or opts.baseUrl).');
  if (!apiKey) throw configError('NINEROUTER_API_KEY is required (env or opts.apiKey).');
  if (!model) throw configError('NINEROUTER_MODEL is required (env or opts.model).');

  const endpoint = new URL('chat/completions', baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/`);

  return {
    async chat({ systemPrompt, messages, tools }) {
      const body = {
        model,
        temperature,
        stream: false, // never let the gateway default us into NDJSON/SSE chunking
        messages: toOpenAiMessages(systemPrompt, messages),
      };
      if (Array.isArray(tools) && tools.length > 0) {
        body.tools = tools.map(toOpenAiTool);
        body.tool_choice = 'auto';
      }
      // Only set response_format when tools are NOT in play — the two are
      // mutually exclusive on every OpenAI-compatible gateway we know of
      // (a JSON-object/json_schema constraint disables function calling).
      if (responseFormat && !body.tools) {
        body.response_format =
          typeof responseFormat === 'string' ? { type: responseFormat } : responseFormat;
      }

      const startedAt = Date.now();
      log.info('chat:request', {
        endpoint: endpoint.toString(),
        model,
        temperature,
        messageCount: body.messages.length,
        toolCount: body.tools ? body.tools.length : 0,
        responseFormat: body.response_format || null,
        apiKey: '[REDACTED]',
      });

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      let res;
      try {
        res = await fetch(endpoint.toString(), {
          method: 'POST',
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify(body),
        });
      } catch (err) {
        log.error('chat:request_failed', { durationMs: Date.now() - startedAt, error: err.message });
        throw clientError(`9router request failed: ${err.message}`, 'REQUEST_FAILED');
      } finally {
        clearTimeout(timer);
      }

      if (!res.ok) {
        const text = await safeText(res);
        log.error('chat:http_error', {
          status: res.status,
          durationMs: Date.now() - startedAt,
          body: text.slice(0, 500),
        });
        throw clientError(`9router returned HTTP ${res.status}: ${text.slice(0, 500)}`, 'HTTP_ERROR');
      }

      const rawText = await safeText(res);
      const payload = parseJsonResponse(rawText);
      const response = fromOpenAiResponse(payload);
      log.info('chat:response', {
        status: res.status,
        durationMs: Date.now() - startedAt,
        responseType: response.type,
        tool: response.tool,
        finishReason: payload && payload.choices && payload.choices[0] && payload.choices[0].finish_reason,
        usage: payload && payload.usage,
      });
      return response;
    },
  };
}

function toOpenAiMessages(systemPrompt, messages) {
  const out = [];
  if (systemPrompt) out.push({ role: 'system', content: systemPrompt });
  for (const m of messages || []) {
    if (m.role === 'assistant' && Array.isArray(m.tool_calls) && m.tool_calls.length > 0) {
      out.push({
        role: 'assistant',
        content: m.content || null,
        tool_calls: m.tool_calls.map((tc) => ({
          id: tc.id,
          type: 'function',
          function: { name: tc.name, arguments: JSON.stringify(tc.args || {}) },
        })),
      });
    } else if (m.role === 'tool') {
      out.push({ role: 'tool', tool_call_id: m.tool_call_id, content: m.content });
    } else {
      out.push({ role: m.role, content: m.content });
    }
  }
  return out;
}

function toOpenAiTool(toolDef) {
  const properties = {};
  const required = [];
  for (const [key, spec] of Object.entries(toolDef.parameters || {})) {
    properties[key] = {
      type: spec.type === 'array' ? 'array' : spec.type === 'object' ? 'object' : spec.type || 'string',
    };
    if (spec.description) properties[key].description = spec.description;
    if (Array.isArray(spec.enum)) properties[key].enum = spec.enum;
    if (spec.required) required.push(key);
  }
  return {
    type: 'function',
    function: {
      name: toolDef.name,
      description: toolDef.description || '',
      parameters: { type: 'object', properties, required },
    },
  };
}

/** Map an OpenAI-shaped chat.completions response to reasoner.js's RawResponse. */
function fromOpenAiResponse(payload) {
  const choice = payload && payload.choices && payload.choices[0];
  const message = choice && choice.message;
  if (!message) {
    throw clientError('9router response missing choices[0].message.', 'BAD_RESPONSE');
  }

  if (Array.isArray(message.tool_calls) && message.tool_calls.length > 0) {
    const call = message.tool_calls[0];
    let args = {};
    try {
      args = call.function && call.function.arguments ? JSON.parse(call.function.arguments) : {};
    } catch (_err) {
      args = {};
    }
    return {
      type: 'tool_call',
      tool: call.function && call.function.name,
      args,
      id: call.id,
      reasoning: message.content || undefined,
    };
  }

  return { type: 'final', content: message.content || '' };
}

/**
 * Parse a chat-completions body defensively. Handles three shapes:
 *   1. Clean single JSON object (the happy path).
 *   2. SSE stream leaked through despite stream:false, e.g.
 *      "data: {...}\n\ndata: {...}\n\ndata: [DONE]\n\n" — take the LAST
 *      "data:" payload that parses (that's the final aggregated chunk on
 *      most gateways) — or merge tool_call arg fragments if it's a real
 *      OpenAI-style delta stream.
 *   3. NDJSON / multiple JSON objects concatenated back to back (the exact
 *      bug reported: "Unexpected non-whitespace character after JSON at
 *      position N") — take the first complete, balanced JSON object.
 */
function parseJsonResponse(rawText) {
  const text = (rawText || '').trim();
  if (!text) throw clientError('9router returned an empty body.', 'BAD_JSON');

  try {
    return JSON.parse(text);
  } catch (_err) {
    // fall through to recovery strategies below
  }

  if (text.includes('data:')) {
    const objects = text
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line.startsWith('data:'))
      .map((line) => line.slice(5).trim())
      .filter((line) => line && line !== '[DONE]')
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch (_err) {
          return null;
        }
      })
      .filter(Boolean);
    if (objects.length > 0) return objects[objects.length - 1];
  }

  const firstObject = extractFirstJsonObject(text);
  if (firstObject) {
    try {
      return JSON.parse(firstObject);
    } catch (_err) {
      // give up below with a clear error
    }
  }

  throw clientError(
    `9router returned non-JSON body: could not recover a JSON object from a ` +
      `${text.length}-char response (checked for SSE "data:" framing and NDJSON ` +
      `concatenation). First 200 chars: ${text.slice(0, 200)}`,
    'BAD_JSON',
  );
}

/** Balanced-brace scan: returns the substring of the first complete {...} object, or null. */
function extractFirstJsonObject(text) {
  const start = text.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
    } else if (ch === '{') {
      depth++;
    } else if (ch === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

async function safeText(res) {
  try {
    return await res.text();
  } catch (_err) {
    return '';
  }
}

function clientError(message, code) {
  const err = new Error(message);
  err.code = code || 'NINEROUTER_ERROR';
  return err;
}

function configError(message) {
  return clientError(message, 'CONFIG_ERROR');
}

export default createNineRouterClient;
